﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CajeroAutomatico.CuentasBancaria
{
    public class CuentaPremium : CuentaBancariaBase
    {
         string? nombreCompleto;
         string? idUsuario;
         string? numCel;
         string? email;
         string? dOB;

        public CuentaPremium(string idCuenta, string nombrePropietario,
            double balance, string TipoCuenta, string FechaCreacion, double MontoApertura) : base(idCuenta, nombrePropietario, balance, TipoCuenta, FechaCreacion, MontoApertura) { }

        public CuentaPremium(string? nombreCompleto, string? idUsuario, string? numCel, string? email, string? dOB, double balance)
        {
            this.nombreCompleto = nombreCompleto;
            this.idUsuario = idUsuario;
            this.numCel = numCel;
            this.email = email;
            this.dOB = dOB;
            Balance = balance;
        }

        public override void MontoApertura(double monto)
        {
            base.Balance += monto;
        }

        public override void Depositar(double monto)
        {
            base.Balance += monto;
        }

        public override void Retirar(double monto)
        {
            base.Balance -= monto;
        }

        public override string ToString()
        {
            string respuesta = "Id Cuenta: " + base.IdCuenta +
                "\nNombre Propietario: " + base.NombrePropietario +
                "\nBalance: " + base.Balance +
                "\nFecha Creacion: " + base.fechaCreacion +
                "\nTipo de Cuenta: " + base.tipoCuenta;


            return respuesta;
        }
    }
}
