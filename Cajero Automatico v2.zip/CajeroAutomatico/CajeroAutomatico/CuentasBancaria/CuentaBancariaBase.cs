﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CajeroAutomatico.CuentasBancaria
{
    public abstract class CuentaBancariaBase
    {
        //Definición de propiedades automaticas
        public string IdCuenta { get; set; }
        public string NombrePropietario { get; set; }
        public string tipoCuenta { get; set; }
        public string fechaCreacion { get; set; }
        public double Balance { get; set; }
        public double montoApertura { get; set; }

        //Constructor por defecto
        public CuentaBancariaBase() { }
        //Definición del constructor e inicialización de propiedades
        public CuentaBancariaBase(string idCuenta, string nombrePropietario,
            double balance, string TipoCuenta, string FechaCreacion, double MontoApertura)
        {
            IdCuenta = idCuenta;
            NombrePropietario = nombrePropietario;
            Balance = balance;
            tipoCuenta = TipoCuenta;
            fechaCreacion = FechaCreacion;
            montoApertura = MontoApertura;
        }
        //Definición de Metodos abstractos
        public abstract void MontoApertura(double monto);
        public abstract void Depositar(double monto);
        public abstract void Retirar(double monto);
    }
}
