﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CajeroAutomatico.CuentasBancaria;

namespace CajeroAutomatico
{
    public class Program
    {
        public static void Main(string[] args)
        {
            List<CuentaBancariaBase> listaCuentaBancaria = new List<CuentaBancariaBase>();
            int opcion = 0;
            double id = 001;
            double pin = 1416;
            int opcionCliente = 0;
            int opcionAdmin = 0;
            double montoCuenta;
            double desposito = 0;
            double retiro = 0;

            do
            {

                Menu();
                opcion = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();

                switch (opcion)
                {
                    case 1:
                        Console.WriteLine("Ingrese su ID de cuenta");
                        id = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Ingrese su PIN");
                        pin = Convert.ToInt32(Console.ReadLine());

                        if (id == 001 & pin == 1416) {
                            Console.WriteLine("");
                            Console.WriteLine("Ha ingresado sesion exitosamente") ;
                            Console.WriteLine("");

                            do
                            {

                                MenuCliente();
                                opcionCliente = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine() ;

                                switch (opcionCliente)
                                {
                                    case 1:
                                        Console.WriteLine();
                                        Console.WriteLine("=================Depósito a Cuenta=================");
                                        Console.WriteLine();
                                        string cuentaDepositar = Console.ReadLine();

                                        Console.WriteLine("Ingrese el valor a depositar");
                                        double valorDepositar = Convert.ToDouble(Console.ReadLine());

                                        CuentaBancariaBase temporal = listaCuentaBancaria.Find(c => c.IdCuenta == cuentaDepositar);

                                        break;

                                    case 2:
                                        Console.WriteLine();
                                        Console.WriteLine("=================Retiro a Cuenta=================");
                                        Console.WriteLine();

                                        break;
                                }



                            } while (opcionCliente != 4);
                        }

                        else
                        {
                            Console.WriteLine("");
                            Console.WriteLine("Numero de ID o PIN incorrecto");
                            Console.WriteLine("");
                        }

                        break;

                    case 2:

                        int opcionGestionUsuario;

                        Console.WriteLine();
                        Console.WriteLine("=================Gestion de Usuarios: =================");
                        Console.WriteLine("1. Registro de Usuarios");
                        Console.WriteLine("2. Baja de Usuarios");
                        Console.WriteLine("3. Salir");
                        Console.WriteLine();
                        opcionGestionUsuario = Convert.ToInt32(Console.ReadLine);

                        switch (opcionGestionUsuario)
                        {
                            case '1':

                                int opcionTipoCuenta = 0;
                                Console.WriteLine("Elija el tipo de cuenta que desea crear:");
                                Console.WriteLine("1. Cuenta Basica");
                                Console.WriteLine("2. Cuenta Premium");
                                opcionTipoCuenta = Convert.ToInt16(Console.ReadLine());
                                Console.WriteLine();   

                                Console.WriteLine("Ingrese su nombre y apellido");
                                string nombreCompleto = Console.ReadLine();
                                Console.WriteLine("Ingrese su ID");
                                string IdUsuario = Console.ReadLine();
                                Console.WriteLine("Ingrese su numero de telefeno en el siguiente formato: XXXX-XXXX");
                                string numCel = Console.ReadLine();
                                Console.WriteLine("Ingrese su correo electronico");
                                string Email = Console.ReadLine();
                                Console.WriteLine("Ingrese su fecha de nacimiento");
                                string DOB = Console.ReadLine();
                                Console.WriteLine("Ingrese un PIN de seguridad");
                                double PinSecurity = Convert.ToDouble(Console.ReadLine());
                                double balance = Convert.ToDouble(Console.ReadLine());

                                if (opcionTipoCuenta == 1)
                                {
                                    CuentaBasica nuevaCuentaB = new CuentaBasica(nombreCompleto, IdUsuario, numCel, Email, DOB, balance);
                                    listaCuentaBancaria.Add(nuevaCuentaB);

                                    balance = 100;
                                }
                                else if (opcionTipoCuenta == 2)
                                {
                                    CuentaPremium nuevaCuentaP = new CuentaPremium(nombreCompleto, IdUsuario, numCel, Email, DOB, balance);
                                    listaCuentaBancaria.Add(nuevaCuentaP);

                                    balance = 1500;
                                }

                                break;
                        }

                        break;
                }


            } while (opcion != 5);
        }


        public static void Menu()
        {
            Console.WriteLine("Control de Cuentas Bancarias");
            Console.WriteLine("1. Inicio de Sesión");
            Console.WriteLine("2. Gestión de Usuarios");
            Console.WriteLine("3. Gestión de Cuentas Bancarias");
            Console.WriteLine("4. Flujo Principal");
            Console.WriteLine("5. Salir");

        }

        public static void MenuCliente()
        {
            Console.WriteLine("***Menu Clientes***");
            Console.WriteLine("1. Depositar");
            Console.WriteLine("2. Retirar");
            Console.WriteLine("3. Verificar Saldo");
            Console.WriteLine("4. Salir");
        }

        public static void MenuAdmin()
        {
            Console.WriteLine("***Menu Administradores***");
            Console.WriteLine("1. Registrar usuario");
            Console.WriteLine("2. Dar de baja un usuario");
            Console.WriteLine("3. Agregar cuenta");
            Console.WriteLine("4. Dar de baja una cuenta");
            Console.WriteLine("5. Salir");
        }
    }
}